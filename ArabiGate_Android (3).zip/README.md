# بوابة العربي

ارفع الملف ArabiGate_Android.zip على GitHub (فرع main) وفعّل Build APK من Actions، ثم نزّل ArabiGate-APK.
من واتساب: افتح ملف الإكسل > مشاركة > بوابة العربي، وهيتحدث ملف المطابقة لوحده.
بعد التثبيت افتح ⚙ وحط مفتاح Gemini API.
