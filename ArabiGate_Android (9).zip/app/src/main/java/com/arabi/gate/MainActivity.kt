package com.arabi.gate

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.util.Base64
import android.view.WindowManager
import android.webkit.GeolocationPermissions
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.webkit.WebViewAssetLoader
import java.io.File
import java.io.FileInputStream

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var pendingMic: PermissionRequest? = null
    private var geoOrigin: String? = null
    private var geoCb: GeolocationPermissions.Callback? = null
    private var fileCb: ValueCallback<Array<Uri>>? = null
    private var sharedName: String = ""
    private var outStream: java.io.OutputStream? = null
    private var outName: String = ""

    inner class Bridge {
        @JavascriptInterface
        fun takeShare(): String = sharedName

        @JavascriptInterface
        fun saveStart(name: String, mime: String): Boolean {
            return try {
                outStream?.close()
                val v = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.MIME_TYPE, mime)
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)!!
                outStream = contentResolver.openOutputStream(uri)
                outName = name
                true
            } catch (e: Exception) {
                false
            }
        }

        @JavascriptInterface
        fun saveChunk(b64: String): Boolean = try {
            outStream!!.write(Base64.decode(b64, Base64.DEFAULT))
            true
        } catch (e: Exception) {
            false
        }

        @JavascriptInterface
        fun saveEnd(): Boolean = try {
            outStream?.close()
            outStream = null
            runOnUiThread { Toast.makeText(this@MainActivity, "اتحفظ في Downloads: $outName", Toast.LENGTH_LONG).show() }
            true
        } catch (e: Exception) {
            false
        }

        @JavascriptInterface
        fun clearShare() {
            sharedName = ""
            File(cacheDir, "shared.bin").delete()
        }

        @JavascriptInterface
        fun save(name: String, b64: String, mime: String): Boolean {
            return try {
                val bytes = Base64.decode(b64, Base64.DEFAULT)
                val v = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.MIME_TYPE, mime)
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)!!
                contentResolver.openOutputStream(uri)!!.use { it.write(bytes) }
                runOnUiThread { Toast.makeText(this@MainActivity, "اتحفظ في Downloads: $name", Toast.LENGTH_LONG).show() }
                true
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this@MainActivity, "تعذر حفظ الملف", Toast.LENGTH_LONG).show() }
                false
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        web = WebView(this)
        setContentView(web)

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .addPathHandler("/shared/", WebViewAssetLoader.PathHandler { _ ->
                val f = File(cacheDir, "shared.bin")
                if (f.exists()) WebResourceResponse("application/octet-stream", null, FileInputStream(f)) else null
            })
            .build()

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            userAgentString = userAgentString + " ArabiGate/1.0"
        }
        web.addJavascriptInterface(Bridge(), "Android")
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                if (request.url.host == "appassets.androidplatform.net") return false
                startActivity(Intent(Intent.ACTION_VIEW, request.url))
                return true
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread {
                    if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                        request.grant(request.resources)
                    } else {
                        pendingMic = request
                        requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
                    }
                }
            }

            override fun onGeolocationPermissionsShowPrompt(origin: String, callback: GeolocationPermissions.Callback) {
                if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                    callback.invoke(origin, true, false)
                } else {
                    geoOrigin = origin
                    geoCb = callback
                    requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 2)
                }
            }

            override fun onShowFileChooser(
                webView: WebView, callback: ValueCallback<Array<Uri>>, params: FileChooserParams
            ): Boolean {
                fileCb?.onReceiveValue(null)
                fileCb = callback
                val i = Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                }
                startActivityForResult(Intent.createChooser(i, "اختر الملف"), 3)
                return true
            }
        }
        if (savedInstanceState == null) takeShare(intent)
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    private fun takeShare(i: Intent?): Boolean {
        if (i == null) return false
        @Suppress("DEPRECATION")
        val uri: Uri? = when (i.action) {
            Intent.ACTION_SEND ->
                if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
                else i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
            Intent.ACTION_VIEW -> i.data
            else -> null
        }
        if (uri == null) return false
        return try {
            var name = ""
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) name = c.getString(0) ?: ""
            }
            if (name.isEmpty()) name = uri.lastPathSegment ?: "shared.xlsx"
            contentResolver.openInputStream(uri)!!.use { input ->
                File(cacheDir, "shared.bin").outputStream().use { out -> input.copyTo(out) }
            }
            sharedName = name
            true
        } catch (e: Exception) {
            false
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (takeShare(intent)) web.evaluateJavascript("window.checkShare&&checkShare()", null)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == 3) {
            val u = data?.data
            fileCb?.onReceiveValue(if (resultCode == RESULT_OK && u != null) arrayOf(u) else null)
            fileCb = null
        } else {
            super.onActivityResult(requestCode, resultCode, data)
        }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        val granted = results.isNotEmpty() && results[0] == PackageManager.PERMISSION_GRANTED
        if (code == 1) {
            pendingMic?.let { if (granted) it.grant(it.resources) else it.deny() }
            pendingMic = null
        } else if (code == 2) {
            geoCb?.invoke(geoOrigin, granted, false)
            geoCb = null
            geoOrigin = null
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
