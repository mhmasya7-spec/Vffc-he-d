# بوابة العربي

ارفع المجلد ده على GitHub (فرع main) وافتح Actions > Build APK، وبعد ما يخلص نزّل ArabiGate-APK.
بعد التثبيت افتح ⚙ داخل التطبيق وحط مفتاح Gemini API.
